Intel Extreme Tuning Utility (XTU) 7.14.2.14
 ~ xeon.best

Support for LGA2011-3 and earlier is NOT included; if you are looking for this, please download the older version.

SHA256 (XTUSetup_7.14.2.14.exe): c79efd826cec71aa33dfe9f128b23dfbcecaa5d0a9062764aab45dee07e6fcc9