Intel Extreme Tuning Utility (XTU) 6.5.2.40
 ~ xeon.best

Support for LGA2011-3 and earlier is included

SHA256 (XTUSetup_6.5.2.40.exe): 7cc2ed8102602fb357aeef9e9fa7785b8f5f548244e4158c0306b559fd08859c